#*** Causal inference test ***
#Author: Minghui Wang
#modified based on the cit package by Joshua Millstein
#
#Input
#L: matrix of instrumental variables
#G: matrix of candidate causal mediators
#T: matrix of traits
#trios: matrix with 3 columns where each row contains 3 indicies pointing to the columns of L,G,T to test.
#maxit: maximum number of permutations (no less than 1000)
#
citfun=function(L,G,T,trios=c(1,1,1),maxit=10000){
	if(maxit<1000) maxit=1000
	L=as.matrix(L)
	G=as.matrix(G)
	T=as.matrix(T)
	if(nrow(L)!=nrow(G) || nrow(L)!=nrow(T)) stop('incompatible dimensions')
	if(is.vector(trios)) trios=matrix(trios,nrow=1)
	trios=as.matrix(trios)
	if(ncol(trios)<3) stop('"trios" must have at least three columns\n')

	firstloop = 1000;
	posno = 10;
	alpha = .01;
	computeCIT=function(x){
		presentObs = !(is.na(T[,x[3]]) | is.na(L[,x[1]]) | is.na(G[,x[2]]))
		To=T[presentObs,x[3]]
		Go=G[presentObs,x[2]]
		if(all(L[presentObs,x[1]] %in% c(0,1,2))){ #discrete
			nAlleles=max(L[,x[1]],na.rm=TRUE)
			LL=lapply(L[presentObs,x[1]],function(a){
				if(a==0) return(rep(0,nAlleles))
				if(a==1) return(if(nAlleles>1){c(0,1)}else{1})
				if(a==2) return(rep(1,nAlleles))
				stop(paste('Unknown genotype',a))
			})
			LL=do.call(rbind,LL)
			LL=LL[,! apply(LL,2,function(x) all(x==x[1])),drop=FALSE]
			nAlleles=ncol(LL)
			if(nAlleles==0) return(rep(NA,5))
		}else{
			nAlleles=1
			LL=L[presentObs,x[1]]
		}
		nvars = nAlleles
		ip = nvars + 1
		nobs=sum(presentObs)
		rss=lmRss(cbind(1,LL),To)
		tss=var(To)*(nobs-1)
		df1 = nvars;
		df2 = nobs - ip;
		F = df2*(tss-rss)/(rss*df1);
		pv1 = pf(F, df1, df2, lower.tail=FALSE);
		
		rss1=lmRss(cbind(1,LL,Go),To)
		df1 = 1;
		df2 = nobs - ip -1;
		F = df2*(rss-rss1)/(rss1*df1);
		pv2 = pf(F, df1, df2, lower.tail=FALSE);
		
		rss2=lmRss(cbind(1,To),Go)

		rss3=lmRss(cbind(1,LL,To),Go)
		df1 = nAlleles;
		df2 = nobs - ip -1;
		F = df2*(rss2-rss3)/(rss3*df1);
		pv3 = pf(F, df1, df2, lower.tail=FALSE);
		
		pvec=c(pv1,pv2,pv3)
		if(any(is.na(pvec))) return(c(NA,pvec,NA))

		rss4=lmRss(cbind(1,Go),To)
		df1 = nAlleles;
		df2 = nobs - ip -1;
		F = df2*(rss4-rss1)/(rss1*df1);
		
		gresid=lmRss(cbind(1,LL),Go,return.residuals=TRUE)
		if(any(is.na(gresid))) return(c(NA,pvec,NA))
		gpred=Go-gresid
		
		#
		npos = 0;
		maxp = max(pvec);
		if(maxp >= alpha) maxit=1000;
		nperm = 0;
		while(nperm  < maxit){
			Gp=gpred+sample(gresid,nobs,replace=FALSE)
			rss4p=lmRss(cbind(1,Gp),To)
			rss1p=lmRss(cbind(1,LL,Gp),To)
			
			df1 = nAlleles;
			df2 = nobs - ip - 1;
			Fp = df2*(rss4p-rss1p)/(rss1p*df1);
			if(Fp < F) npos=npos+1;
			nperm=nperm+1
			if(nperm>firstloop){
				if(npos >= posno) break
				testval = npos / nperm
				if( maxp >= testval) break # check that other component p-values are small
			}
		}
		pv4 = npos / nperm;
		pvec=c(pvec,pv4);
		return(c(max(pvec),pvec))
	}
	#
	Result=apply(trios,1,computeCIT) # End tst loop
	Result=data.frame(trios,t(Result),stringsAsFactors=FALSE)
	colnames(Result)=c('L_index','G_index','T_index','p_cit','p_TassocL','p_TassocGgvnL','p_GassocLgvnT','p_LindTgvnG')
	Result
}
lmRss=function(x, y, tol = 1e-07,return.residuals=FALSE) {
	x=as.matrix(x)
	n=nrow(x)
	if(n != length(y)) stop("incompatible dimensions")
	m=ncol(x)
	se=b=rep(0.0,m)
	res=rep(0.0,n)
	mse=0.0
	ierr=0L
	z <- .Fortran('lsq',n=n,m=m,y=as.double(y),X=as.double(x),b=b,se=se,res=res,mse=mse,ierr=ierr)
	if(z[[9]] != 0L) return(NA) #the design matrix is probably not in full rank.
	RSS=z[[7]]
	if(return.residuals==FALSE) RSS=sum(RSS^2)
	RSS
}
